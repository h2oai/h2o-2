if ("package:h2o" %in% search()) {detach("package:h2o", unload=TRUE)}
if ("h2o" %in% rownames(installed.packages())) {remove.packages("h2o")}

# Install most up to date H2O package
install.packages("/Users/arielrao/h2o/target/R/bin/macosx/contrib/3.0/h2o_2.5.0.99999.tgz",repos = NULL)
library("h2o")  
localH20  <- h2o.init(ip="192.168.1.162", port=22211)

print("Reading in original prostate data.")
prostate.data <- h2o.uploadFile(localH20, "/Users/arielrao/Documents/Datasets/prostate.csv", key="prostate.data",header=TRUE)
head(prostate.data) ; dim(prostate.data)

BIN <- h2o.uploadFile(localH20, "/Users/arielrao/Documents/Datasets/prostate.bin.csv", key="BIN", header=FALSE)
FLOAT <- h2o.uploadFile(localH20, "/Users/arielrao/Documents/Datasets/prostate.float.csv", key="FLOAT", header=FALSE)
INT <- h2o.uploadFile(localH20, "/Users/arielrao/Documents/Datasets/prostate.int.csv", key="INT", header=FALSE)
dim(BIN) ; dim(FLOAT) ; dim(INT)
prostate.data <- cbind(prostate.data, BIN, FLOAT, INT)
head(prostate.data) ; dim(prostate.data) ; summary(prostate.data)

prostate.data$split <- ifelse(h2o.runif(prostate.data)>0.8, yes=1, no=0)
prostate.train <- h2o.assign(prostate.data[prostate.data$split == 0, c(1:12)], "prostate.train")
prostate.test <- h2o.assign(prostate.data[prostate.data$split == 1, c(1:12)], "prostate.test")
dim(prostate.train) ; dim(prostate.test)

prostate.def.model <- h2o.glm(x=c("ID","CAPSULE","AGE","RACE","DPROS","DCAPS","PSA","VOL"), y=c("GLEASON"), prostate.train, family="gaussian", lambda_search=TRUE, alpha=1)
prostate.bin.model <- h2o.glm(x=c("ID","CAPSULE","AGE","RACE","DPROS","DCAPS","PSA","VOL","BIN"), y=c("GLEASON"), prostate.train, family="gaussian", lambda_search=TRUE, alpha=1)
prostate.float.model <- h2o.glm(x=c("ID","CAPSULE","AGE","RACE","DPROS","DCAPS","PSA","VOL","FLOAT"), y=c("GLEASON"), prostate.train, family="gaussian", lambda_search=TRUE, alpha=1)
prostate.int.model <- h2o.glm(x=c("ID","CAPSULE","AGE","RACE","DPROS","DCAPS","PSA","VOL","INT"), y=c("GLEASON"), prostate.train, family="gaussian", lambda_search=TRUE, alpha=1)
prostate.all.model <- h2o.glm(x=c("ID","CAPSULE","AGE","RACE","DPROS","DCAPS","PSA","VOL","BIN","FLOAT","INT"), y=c("GLEASON"), prostate.train, family="gaussian", lambda_search=TRUE, alpha=1)

prostate.def.predict <- h2o.predict(prostate.def.model,prostate.train)
prostate.bin.predict <- h2o.predict(prostate.bin.model,prostate.train)
prostate.float.predict <- h2o.predict(prostate.float.model,prostate.train)
prostate.int.predict <- h2o.predict(prostate.int.model,prostate.train)
prostate.all.predict <- h2o.predict(prostate.all.model,prostate.train)